import OrderSuccess from '@/components/(customer)/OrderSuccess'
import React from 'react'

const page = () => {
  return (
   <OrderSuccess/>
  )
}

export default page