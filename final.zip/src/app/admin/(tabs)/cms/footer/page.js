import Footer from '@/components/(admin)/sections/Footer'
import React from 'react'

const page = () => {
  return (
   <Footer/>
  )
}

export default page