"use client "
import React from 'react'

const page = () => {
  return (
    <div>page</div>
  )
}


export default page