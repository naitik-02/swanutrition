// app/admin/layout.js
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AdminShell from "@/components/Layout/AdminShell.jsx";

export default function AdminLayout({ children }) {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  // ⭐ Ensure client-side only
  useEffect(() => {
    setMounted(true);
    
    const adminAuth = localStorage.getItem('adminAuth');
    const hasCookie = document.cookie.includes('adminToken');
    
    console.log("🔐 Auth Check:", { adminAuth: !!adminAuth, hasCookie });
    
    if (!adminAuth && !hasCookie) {
      console.log("❌ Not authenticated, redirecting...");
      router.push('/auth/dashboard-login');
    }
  }, [router]);

  // ⭐ Show loading until mounted (avoids SSR issues)
  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return <AdminShell>{children}</AdminShell>;
}