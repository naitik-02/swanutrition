export default function AccountIndexPage() {
  return (
    <div className="text-gray-500 text-center">
      Please select a tab from the left to view your account details.
    </div>
  );
}