/** @type {import('next').NextConfig} */
export default {

  trailingSlash: true, 
  images: {
    unoptimized: true,
  },
};