import Header from '../../../../../components/(admin)/sections/Header'
import React from 'react'

const page = () => {
  return (
    <Header/>
  )
}

export default page