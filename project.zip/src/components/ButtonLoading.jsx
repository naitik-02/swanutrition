import React from 'react'

const ButtonLoading = () => {
  return (
    <div>Loading...</div>
  )
}

export default ButtonLoading