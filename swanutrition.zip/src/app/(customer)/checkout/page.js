"use client";

export const dynamic = "force-dynamic";

import Checkout from "@/components/(customer)/pages/Checkout";

export default function Page() {
  return <Checkout />;
}
