"use client"
import AddVideo from '@/components/(admin)/sections/AddVideo'
import React from 'react'

const page = () => {
  return (
   <AddVideo/>
  )
}

export default page