import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import AdminShell from "@/components/Layout/AdminShell.jsx";

export default async function AdminLayout({ children }) {
  const cookieStore = await cookies();
  const token = cookieStore.get("adminToken")?.value;
  console.log(token)

  if (!token) {
    redirect("/auth/dashboard-login");
  }

  return <AdminShell>{children}</AdminShell>;
}
