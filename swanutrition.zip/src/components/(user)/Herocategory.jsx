import React from 'react'

const Herocategory = () => {
  return (
    <div className="bg-green-700 py-10 px-4 ">
         <h1 className='text-white'>Paan corner</h1>
         <p className='text-white'>Your Favourite paan shop is now Online</p>
         <button className='p-2 border-[1px] '>
            Shop Now
         </button>
    </div>
  )
}

export default Herocategory