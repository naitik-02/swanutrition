import React from 'react'

const Security = () => {
  return (
    <div>Security</div>
  )
}

export default Security