import React from 'react'

const SingleBlog = () => {
  return (
    <div>SingleBlog</div>
  )
}

export default SingleBlog